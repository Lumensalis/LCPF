
# This is a factory for adding Adafruit Stemma/QT modules

from LumensalisCP.I2C.I2CFactory import I2CFactory

class SparkfunI2CFactory(I2CFactory):
    pass
