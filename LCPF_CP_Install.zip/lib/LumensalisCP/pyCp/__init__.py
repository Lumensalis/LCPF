""" 
CircuitPython versions of "standard" python modules
  - some provide for missing modules (like **weakref**)
  - some override / extend existing CircuitPython versions (like **collections**)
"""