from __future__ import annotations

from LumensalisCP.Main.PreMainConfig import pmc_getImportProfiler
_sayImport = pmc_getImportProfiler( "Triggers.__init__" )

_sayImport.complete(globals())


