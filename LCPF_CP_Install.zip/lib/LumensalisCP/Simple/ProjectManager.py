
from __future__ import annotations

import rainbowio
import gc

# pyright: ignore[reportUnusedImport]
# pylint: disable=unused-import,import-error,unused-argument 
# pyright: reportMissingImports=false, reportImportCycles=false, reportUnusedImport=false

from LumensalisCP.Main.PreMainConfig import pmc_getImportProfiler
_saySimpleImport = pmc_getImportProfiler( "Simple.ProjectManager" )


from LumensalisCP.common import *

from LumensalisCP.Triggers.Timer import PeriodicTimer

from LumensalisCP.Eval.EvaluationContext import EvaluationContext


from LumensalisCP.Main.Manager import MainManager



def ProjectManager( profile:Optional[bool]=None, profileMemory:Optional[bool|int]=None ) -> MainManager:
    """ return the MainManager for a new simple project 
```python
from LumensalisCP.Simple import *
main = ProjectManager()

# configure your project here...

main.launchProject( globals() )
```
see http://lumensalis.com/ql/h2Main
"""
    if profile is not None:
        pmc_mainLoopControl.ENABLE_PROFILE = profile
        if profileMemory is not None:
            if isinstance(profileMemory, bool):
                pmc_gcManager.PROFILE_MEMORY = profileMemory
            else:
                pmc_gcManager.PROFILE_MEMORY = True
                if profileMemory & 1: pmc_gcManager.PROFILE_MEMORY_NESTED = True
                if profileMemory & 2: pmc_gcManager.PROFILE_MEMORY_ENTRIES = True

    if pmc_mainLoopControl.ENABLE_PROFILE:
        from LumensalisCP.Main.Profiler import ProfileFrame,ProfileSnapEntry,ProfileSubFrame,ProfileFrameBase
        ProfileFrame.releasablePreload( 70 )
        ProfileSubFrame.releasablePreload( 1000 )
        ProfileSnapEntry.releasablePreload( 3000 )

    main = MainManager.initOrGetManager()


    #if pmc_gcManager.PROFILE_MEMORY == True:
    #    pmc_gcManager.PROFILE_MEMORY_NESTED = True
    #    pmc_gcManager.PROFILE_MEMORY_ENTRIES = True
    if  pmc_mainLoopControl.ENABLE_PROFILE:
        pmc_mainLoopControl.sayAtStartup("ProjectManager: starting project with profiling enabled")
    
    gc.collect() # collect garbage before starting the project
    gc.disable()

    def addProfilingCallbacks():
        print("\n\nAdding profiling callbacks...\n")
        import LumensalisCP.Main.ProfilerRL as profilingRL
        #profilingRL.printDump(rv)

        def getCollectionCheckInterval() -> TimeSpanInSeconds:
            rv = profilingRL.collectionCheckInterval
            return rv
        
        timer = PeriodicTimer(manager=main.timers,name="gc-collect",
                              interval=getCollectionCheckInterval, oneShot=False)
        
        #@addPeriodicTaskDef( name="gc-collect", interval=getCollectionCheckInterval, main=main )
        def runCollect(context:EvaluationContext) -> None:
            #print( f"pmc_gcManager.runCollection {context.updateIndex}..." )
            pmc_gcManager.runCollection(context, show=profilingRL.showRunCollection)

        timer.addAction(runCollect)
        timer.start()
        print("\n\n profiling callbacks added...\n")


        #@addPeriodicTaskDef( "print-dump", period=lambda: profilingRL.printDumpInterval, main=main )
        #def dump():
        #    profilingRL.printDump(main)

    main.callLater( addProfilingCallbacks )


    return main

_saySimpleImport.complete(globals())
