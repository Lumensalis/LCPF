from LumensalisCP.Main.PreMainConfig import pmc_getImportProfiler
_sayEval__init__Import = pmc_getImportProfiler( "Eval.__init__" )

_sayEval__init__Import.complete(globals())
